from mininet.topo import Topo
from mininet.net import Mininet
from mininet.link import TCLink
from mininet.log import setLogLevel
from mininet.node import OVSKernelSwitch, RemoteController
from time import sleep
from datetime import datetime
from random import randrange, choice

class MyTopo(Topo):
    def build(self):
        # Define switches and hosts
        s1 = self.addSwitch('s1', cls=OVSKernelSwitch, protocols='OpenFlow13')
        capteur1 = self.addHost('capteur1', cpu=1.0/20, mac="00:00:00:00:00:01", ip="fe80::1/64")
        capteur2 = self.addHost('capteur2', cpu=1.0/20, mac="00:00:00:00:00:02", ip="fe80::2/64")
        capteur3 = self.addHost('capteur3', cpu=1.0/20, mac="00:00:00:00:00:03", ip="fe80::3/64")
        s2 = self.addSwitch('s2', cls=OVSKernelSwitch, protocols='OpenFlow13')
        capteur4 = self.addHost('capteur4', cpu=1.0/20, mac="00:00:00:00:00:04", ip="fe80::4/64")
        capteur5 = self.addHost('capteur5', cpu=1.0/20, mac="00:00:00:00:00:05", ip="fe80::5/64")
        capteur6 = self.addHost('capteur6', cpu=1.0/20, mac="00:00:00:00:00:06", ip="fe80::6/64")
        s3 = self.addSwitch('s3', cls=OVSKernelSwitch, protocols='OpenFlow13')
        capteur7 = self.addHost('capteur7', cpu=1.0/20, mac="00:00:00:00:00:07", ip="fe80::7/64")
        capteur8 = self.addHost('capteur8', cpu=1.0/20, mac="00:00:00:00:00:08", ip="fe80::8/64")
        capteur9 = self.addHost('capteur9', cpu=1.0/20, mac="00:00:00:00:00:09", ip="fe80::9/64")
        s4 = self.addSwitch('s4', cls=OVSKernelSwitch, protocols='OpenFlow13')
        capteur10 = self.addHost('capteur10', cpu=1.0/20, mac="00:00:00:00:00:10", ip="fe80::10/64")
        capteur11 = self.addHost('capteur11', cpu=1.0/20, mac="00:00:00:00:00:11", ip="fe80::11/64")
        capteur12 = self.addHost('capteur12', cpu=1.0/20, mac="00:00:00:00:00:12", ip="fe80::12/64")
        s5 = self.addSwitch('s5', cls=OVSKernelSwitch, protocols='OpenFlow13')
        capteur13 = self.addHost('capteur13', cpu=1.0/20, mac="00:00:00:00:00:13", ip="fe80::13/64")
        capteur14 = self.addHost('capteur14', cpu=1.0/20, mac="00:00:00:00:00:14", ip="fe80::14/64")
        capteur15 = self.addHost('capteur15', cpu=1.0/20, mac="00:00:00:00:00:15", ip="fe80::15/64")
        s6 = self.addSwitch('s6', cls=OVSKernelSwitch, protocols='OpenFlow13')
        capteur16 = self.addHost('capteur16', cpu=1.0/20, mac="00:00:00:00:00:16", ip="fe80::16/64")
        capteur17 = self.addHost('capteur17', cpu=1.0/20, mac="00:00:00:00:00:17", ip="fe80::17/64")
        capteur18 = self.addHost('capteur18', cpu=1.0/20, mac="00:00:00:00:00:18", ip="fe80::18/64")

        # Add links
        self.addLink(capteur1, s1)
        self.addLink(capteur2, s1)
        self.addLink(capteur3, s1)
        self.addLink(capteur4, s2)
        self.addLink(capteur5, s2)
        self.addLink(capteur6, s2)
        self.addLink(capteur7, s3)
        self.addLink(capteur8, s3)
        self.addLink(capteur9, s3)
        self.addLink(capteur10, s4)
        self.addLink(capteur11, s4)
        self.addLink(capteur12, s4)
        self.addLink(capteur13, s5)
        self.addLink(capteur14, s5)
        self.addLink(capteur15, s5)
        self.addLink(capteur16, s6)
        self.addLink(capteur17, s6)
        self.addLink(capteur18, s6)
        self.addLink(s1, s2)
        self.addLink(s2, s3)
        self.addLink(s3, s4)
        self.addLink(s4, s5)
        self.addLink(s5, s6)

def ipv6_generator():
    ip = "fe80::{}".format(randrange(1, 19))
    return ip
        
def startNetwork():
    topo = MyTopo()
    c0 = RemoteController('c0', ip='192.168.152.132', port=6653)
    net = Mininet(topo=topo, link=TCLink, controller=c0)

    net.start()
    
    capteur1 = net.get('capteur1')
    capteur2 = net.get('capteur2')
    capteur3 = net.get('capteur3')
    capteur4 = net.get('capteur4')
    capteur5 = net.get('capteur5')
    capteur6 = net.get('capteur6')
    capteur7 = net.get('capteur7')
    capteur8 = net.get('capteur8')
    capteur9 = net.get('capteur9')
    capteur10 = net.get('capteur10')
    capteur11 = net.get('capteur11')
    capteur12 = net.get('capteur12')
    capteur13 = net.get('capteur13')
    capteur14 = net.get('capteur14')
    capteur15 = net.get('capteur15')
    capteur16 = net.get('capteur16')
    capteur17 = net.get('capteur17')
    capteur18 = net.get('capteur18')
    
    sensors = [capteur1, capteur2, capteur3, capteur4, capteur5, capteur6, capteur7, capteur8, capteur9, capteur10, capteur11, capteur12, capteur13, capteur14, capteur15, capteur16, capteur17, capteur18]    
    print("--------------------------------------------------------------------------------")    
    print("Generating traffic ...")    
    capteur1.cmd('cd /home/mininet/webserver')
    capteur1.cmd('python3 -m http.server 80 &')
    capteur1.cmd('iperf -s -p 5050 &')
    capteur1.cmd('iperf -s -u -p 5051 &')
    sleep(2)
    for c in sensors:
        c.cmd('cd /home/mininet/Downloads')
    for i in range(600):
        
        print("--------------------------------------------------------------------------------")    
        print("Iteration n {} ...".format(i+1))
        print("--------------------------------------------------------------------------------") 
        
        for j in range(10):
            src = choice(sensors)
            dst = ipv6_generator()
            
            if j < 9:
                print("Generating ICMPv6 traffic between %s and %s and TCP/UDP traffic between %s and capteur1" % (src, dst, src))
                src.cmd("ping6 {} -c 100 &".format(dst))
                src.cmd("iperf -p 5050 -c fe80::1")
                src.cmd("iperf -p 5051 -u -c fe80::1")
            else:
                print("Generating ICMPv6 traffic between %s and %s and TCP/UDP traffic between %s and capteur1" % (src, dst, src))
                src.cmd("ping6 {} -c 100".format(dst))
                src.cmd("iperf -p 5050 -c fe80::1")
                src.cmd("iperf -p 5051 -u -c fe80::1")
				
            print("%s Downloading index.html from capteur1" % src)
            src.cmd("wget http://fe80::1/index.html")
            print("%s Downloading test.zip from capteur1" % src)
            src.cmd("wget http://fe80::1/test.zip")
        
        capteur1.cmd("rm -f *.* /home/mininet/Downloads")
        
    print("--------------------------------------------------------------------------------")  
    
    # CLI(net)
    net.stop()

if __name__ == '__main__':
    
    start = datetime.now()
    
    setLogLevel( 'info' )
    startNetwork()
    
    end = datetime.now()
    
    print(end-start)
