# -*- coding: utf-8 -*-

from __future__ import unicode_literals
import streamlit as st
import networkx as nx
import matplotlib.pyplot as plt
from mininet.topo import Topo
from mininet.net import Mininet
from mininet.link import TCLink
from mininet.log import setLogLevel
from mininet.node import OVSKernelSwitch, RemoteController
from mininet.cli import CLI

class MyTopo(Topo):
    def build(self):
        # Define switches and hosts
        getway1 = self.addSwitch('getway1', cls=OVSKernelSwitch, protocols='OpenFlow13')
        cap1 = self.addHost('cap1', cpu=1.0/20, mac="00:00:00:00:00:01", ip="10.0.0.1/24")
        cap2 = self.addHost('cap2', cpu=1.0/20, mac="00:00:00:00:00:02", ip="10.0.0.2/24")
        cap3 = self.addHost('cap3', cpu=1.0/20, mac="00:00:00:00:00:03", ip="10.0.0.3/24")
        getway2 = self.addSwitch('getway2', cls=OVSKernelSwitch, protocols='OpenFlow13')
        cap4 = self.addHost('cap4', cpu=1.0/20, mac="00:00:00:00:00:04", ip="10.0.0.4/24")
        cap5 = self.addHost('cap5', cpu=1.0/20, mac="00:00:00:00:00:05", ip="10.0.0.5/24")
        cap6 = self.addHost('cap6', cpu=1.0/20, mac="00:00:00:00:00:06", ip="10.0.0.6/24")
        getway3 = self.addSwitch('getway3', cls=OVSKernelSwitch, protocols='OpenFlow13')
        cap7 = self.addHost('cap7', cpu=1.0/20, mac="00:00:00:00:00:07", ip="10.0.0.7/24")
        cap8 = self.addHost('cap8', cpu=1.0/20, mac="00:00:00:00:00:08", ip="10.0.0.8/24")
        cap9 = self.addHost('cap9', cpu=1.0/20, mac="00:00:00:00:00:09", ip="10.0.0.9/24")
        getway4 = self.addSwitch('getway4', cls=OVSKernelSwitch, protocols='OpenFlow13')
        cap10 = self.addHost('cap10', cpu=1.0/20, mac="00:00:00:00:00:10", ip="10.0.0.10/24")
        cap11 = self.addHost('cap11', cpu=1.0/20, mac="00:00:00:00:00:11", ip="10.0.0.11/24")
        cap12 = self.addHost('cap12', cpu=1.0/20, mac="00:00:00:00:00:12", ip="10.0.0.12/24")
        getway5 = self.addSwitch('getway5', cls=OVSKernelSwitch, protocols='OpenFlow13')
        cap13 = self.addHost('cap13', cpu=1.0/20, mac="00:00:00:00:00:13", ip="10.0.0.13/24")
        cap14 = self.addHost('cap14', cpu=1.0/20, mac="00:00:00:00:00:14", ip="10.0.0.14/24")
        cap15 = self.addHost('cap15', cpu=1.0/20, mac="00:00:00:00:00:15", ip="10.0.0.15/24")
        getway6 = self.addSwitch('getway6', cls=OVSKernelSwitch, protocols='OpenFlow13')
        cap16 = self.addHost('cap16', cpu=1.0/20, mac="00:00:00:00:00:16", ip="10.0.0.16/24")
        cap17 = self.addHost('cap17', cpu=1.0/20, mac="00:00:00:00:00:17", ip="10.0.0.17/24")
        cap18 = self.addHost('cap18', cpu=1.0/20, mac="00:00:00:00:00:18", ip="10.0.0.18/24")

        # Add links
        self.addLink(cap1, getway1)
        self.addLink(cap2, getway1)
        self.addLink(cap3, getway1)
        self.addLink(cap4, getway2)
        self.addLink(cap5, getway2)
        self.addLink(cap6, getway2)
        self.addLink(cap7, getway3)
        self.addLink(cap8, getway3)
        self.addLink(cap9, getway3)
        self.addLink(cap10, getway4)
        self.addLink(cap11, getway4)
        self.addLink(cap12, getway4)
        self.addLink(cap13, getway5)
        self.addLink(cap14, getway5)
        self.addLink(cap15, getway5)
        self.addLink(cap16, getway6)
        self.addLink(cap17, getway6)
        self.addLink(cap18, getway6)
        self.addLink(getway1, getway2)
        self.addLink(getway2, getway3)
        self.addLink(getway3, getway4)
        self.addLink(getway4, getway5)
        self.addLink(getway5, getway6)

def visualize_topology(topo):
    # Create a NetworkX graph from the Mininet topology
    G = nx.Graph()

    # Add nodes and edges from the Mininet topology to the NetworkX graph
    for switch in topo.switches():
        G.add_node(switch)
    for host in topo.hosts():
        G.add_node(host)
    for link in topo.links():
        G.add_edge(link[0], link[1])

    # Draw the graph using Matplotlib
    pos = nx.spring_layout(G)
    plt.figure(figsize=(10, 8))
    nx.draw(G, pos, with_labels=True, node_size=3000, node_color='lightblue', font_size=12, font_weight='bold', edge_color='gray')
    st.pyplot(plt)

def startNetwork():
    topo = MyTopo()
    c0 = RemoteController('c0', ip='192.168.152.137', port=6653)
    net = Mininet(topo=topo, link=TCLink, controller=c0)
    net.start()
    visualize_topology(topo)
    CLI(net)
    net.stop()

def main():
    st.title(u"Simulation de réseau SDN avec Mininet")

    # Bouton pour démarrer la simulation
    if st.button("Démarrer la simulation"):
        setLogLevel('info')
        startNetwork()
        st.success("La simulation s'est terminée avec succès!")

if __name__ == "__main__":
    main()

