import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

def app():
    # Charger les données
    data = pd.read_csv('/home/ryu/PFE_IDS_IOT_SDN/controller/FlowStatsfile.csv')

    # Formater la colonne timestamp en datetime
    data['timestamp'] = pd.to_datetime(data['timestamp'], unit='s')

    # Remplacer les valeurs de label par des noms plus descriptifs
    data['label'] = data['label'].replace({0: 'Trafic Normal', 1: 'Trafic Malveillant'})

    # Remplacer les valeurs de ip_proto par des noms de protocoles
    protocol_dict = {1: 'ICMP', 6: 'TCP', 17: 'UDP'}
    data['ip_proto'] = data['ip_proto'].replace(protocol_dict)

    # Affichage de la partie des données
    st.title('Visualisation des Données Réseau')
    st.subheader('Aperçu des Données')
    st.write(data[['timestamp', 'ip_src', 'ip_dst', 'ip_proto', 'label']].head())

    # Bouton pour afficher le graphe secteur du trafic normal vs malveillant
    if st.button('Afficher Trafic Normal vs. Malveillant'):
        st.subheader('Trafic Normal vs. Malveillant')
        fig = px.pie(data, names='label', title='Répartition du Trafic Normal vs. Malveillant',
                     color='label', color_discrete_map={'Trafic Normal': 'green', 'Trafic Malveillant': 'red'})
        fig.update_traces(textinfo='label+percent', pull=[0, 0.2])
        st.plotly_chart(fig)

    # Bouton pour afficher la répartition des protocoles du trafic malveillant
    if st.button('Afficher Répartition des Protocoles du Trafic Malveillant'):
        st.subheader('Répartition des Protocoles du Trafic Malveillant')
        malicious_traffic = data[data['label'] == 'Trafic Malveillant']
        fig2 = px.pie(malicious_traffic, names='ip_proto', title='Répartition des Protocoles (ICMP, TCP, UDP) du Trafic Malveillant',
                      color='ip_proto', color_discrete_map={'ICMP': 'blue', 'TCP': 'orange', 'UDP': 'purple'})
        fig2.update_traces(textinfo='label+percent', pull=[0, 0.2, 0.3])
        st.plotly_chart(fig2)

    # Bouton pour afficher le nuage de points pour le trafic normal et malveillant
    if st.button('Afficher Nuage de Points du Trafic Normal et Malveillant'):
        st.subheader('Nuage de Points du Trafic Normal et Malveillant')
        fig3 = px.scatter(data, x='ip_src', y='ip_dst', color='label', title='Corrélation entre le Trafic Normal et Malveillant',
                          color_discrete_map={'Trafic Normal': 'green', 'Trafic Malveillant': 'red'})
        st.plotly_chart(fig3)

    # Bouton pour afficher le tableau des protocoles et du nombre de paquets malveillants et normaux
    if st.button('Afficher Tableau des Protocoles et Nombre de Paquets'):
        st.subheader('Tableau des Protocoles et Nombre de Paquets')
        protocol_counts = data.groupby(['ip_proto', 'label']).size().unstack(fill_value=0)
        protocol_counts['Total'] = protocol_counts.sum(axis=1)
        protocol_counts.loc['Total'] = protocol_counts.sum()
        st.write(protocol_counts)

if __name__ == "__main__":
    st.run()

