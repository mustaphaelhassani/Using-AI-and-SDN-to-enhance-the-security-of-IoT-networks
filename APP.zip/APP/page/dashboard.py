import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
import datetime
import os

# Charger le logo de l'université
logo_path = "logo_universite_mohamed_v_rabat.png"
if os.path.exists(logo_path):
    logo = Image.open(logo_path)
else:
    logo = None

# Configuration de la page
st.set_page_config(page_title="Statistiques des données", page_icon=logo_path if logo else None, layout='wide')

# Affichage du logo et de la date actuelle
col1, col2 = st.columns([1, 3])
if logo:
    col1.image(logo, width=150)
col2.write(datetime.datetime.now().strftime("%d/%m/%Y %H:%M"))

# Charger les données
data_path = 'data.csv'
if os.path.exists(data_path):
    data = pd.read_csv(data_path)
    
    # Affichage des 10 premières lignes de données
    st.header("Les 10 premières lignes des données")
    st.write(data.head(10))
    
    # Graphique des statistiques de données labélisées
    if 'label' in data.columns:
        st.header("Statistiques des données labélisées")
        
        # Compter les occurrences de chaque label
        label_counts = data['label'].value_counts()
        
        # Graphique barre des statistiques de label
        fig, ax = plt.subplots()
        sns.barplot(x=label_counts.index, y=label_counts.values, ax=ax)
        ax.set_xlabel('Label')
        ax.set_ylabel('Nombre de données')
        st.pyplot(fig)
        
    else:
        st.write("La colonne 'label' n'existe pas dans le fichier CSV.")
else:
    st.write(f"Le fichier {data_path} n'existe pas. Veuillez vérifier le chemin du fichier.")

