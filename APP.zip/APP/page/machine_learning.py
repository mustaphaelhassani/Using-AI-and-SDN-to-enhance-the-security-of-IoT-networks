# app.py
import streamlit as st
import subprocess
import re
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime


def run_ml_script():
    result = subprocess.run(['python3', '/home/ryu/IDS_sdn_network_ddos_detection_using_machine_learning/controller/ML.py'], capture_output=True, text=True)
    return result.stdout, result.stderr

def parse_results(output):
    results = []
    algorithm = None
    for line in output.splitlines():
        if "..." in line:
            algorithm = line.split("...")[0].strip()
        elif "confusion matrix" in line:
            cm = []
        elif re.match(r"^\[\[", line):
            cm.append([int(num) for num in re.findall(r"\d+", line)])
        elif "succes accuracy" in line:
            acc = float(re.findall(r"\d+\.\d+", line)[0]) / 100
            results.append({"Algorithm": algorithm, "Confusion Matrix": cm, "Accuracy": acc})
    return results

def main():
    st.title("Visualisation des résultats des algorithmes de Machine Learning")

    if st.button("Lancer les algorithmes de machine learning"):
        stdout, stderr = run_ml_script()
        if stderr:
            st.error(stderr)
        results = parse_results(stdout)
        st.write("## Résultats")
        for result in results:
            st.write(f"### {result['Algorithm']}")
            st.write(f"Accuracy: {result['Accuracy']*100:.2f}%")
            cm = result['Confusion Matrix']
            fig, ax = plt.subplots()
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax)
            ax.set_title(f"Confusion Matrix for {result['Algorithm']}")
            ax.set_xlabel("Predicted")
            ax.set_ylabel("Actual")
            st.pyplot(fig)

if __name__ == "__main__":
    main()

