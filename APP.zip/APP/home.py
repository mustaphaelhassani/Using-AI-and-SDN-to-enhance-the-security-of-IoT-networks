import streamlit as st
from PIL import Image
import os

def app():
    # Chemin vers le logo
    logo_path = "logo_universite_mohamed_v_rabat.png"

    # Vérification de l'existence du fichier logo
    if os.path.exists(logo_path):
        try:
            logo = Image.open(logo_path)
        except IOError:
            logo = None
    else:
        logo = None

    # Affichage du logo
    if logo:
        st.image(logo, width=150)

    # HTML et CSS pour le style
    st.markdown("""
        <style>
            .title {
                text-align: center;
                color: royalblue;
                font-size: 2.5em;
                margin-top: 20px;
            }
            .project-info {
                text-align: left;
                margin: 20px;
                padding: 10px;
                border: 2px solid #ccc;
                border-radius: 10px;
            }
            .project-info strong {
                color: darkblue;
            }
            .footer {
                position: fixed;
                left: 0;
                bottom: 10px;
                width: 100%;
                text-align: center;
                font-size: 0.8em;
                color: gray;
            }
        </style>
    """, unsafe_allow_html=True)

    # Titre principal
    st.markdown('<div class="title"><h1>Projet de fin de formation : utilisation de SDN sur les réseaux IOT et renforcé la sécurité à l\'aide de Machine Learning</h1></div>', unsafe_allow_html=True)

    # Informations sur le projet
    st.markdown("""
    <div class="project-info">
        <p><strong>Réalisé par :</strong> Mr EL-HASSANI Mustapha</p>
        <p><strong>Encadré par :</strong> Dr OUACHA ALI </p>
    </div>
    """, unsafe_allow_html=True)

    # Footer avec l'année universitaire
    st.markdown('<div class="footer">Année universitaire : 2023/2024</div>', unsafe_allow_html=True)

