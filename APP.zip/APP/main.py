import streamlit as st
from streamlit_option_menu import option_menu
import controller, dashboard, home, machine_learning, mininet

class MultiApp:
    def __init__(self):
        self.apps = []

    def add_app(self, title, function):
        self.apps.append({
            "title": title,
            "function": function
        })

    def run(self):
        with st.sidebar:
            app = option_menu(
                menu_title='PFE2024_ELHASSANI',
                options=['home', 'dashboard', 'controller', 'mininet', 'machine_learning'],
                icons=['house-fill', 'kanban', 'server', 'cpu', 'robot'],
                menu_icon='chat-text-fill',
                default_index=1,
                styles={
                    "container": {"padding": "5!important", "background-color": "#4527A0"},
                    "icon": {"color": "white", "font-size": "23px"},
                    "nav-link": {"color": "white", "font-size": "20px", "text-align": "left"},
                    "nav-link-selected": {"background-color": "#02ab21"},
                }
            )
        for app_entry in self.apps:
            if app == app_entry['title']:
                app_entry['function']()

multi_app = MultiApp()
multi_app.add_app('home', home.app)
multi_app.add_app('dashboard', dashboard.app)
multi_app.add_app('controller', controller.app)
multi_app.add_app('mininet', mininet.app)
multi_app.add_app('machine_learning', machine_learning.app)

if __name__ == "__main__":
    multi_app.run()

