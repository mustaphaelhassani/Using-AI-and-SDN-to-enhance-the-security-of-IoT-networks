import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score
from ML import MachineLearning
import seaborn as sns
import numpy as np

def display_confusion_matrix(cm, title='Confusion Matrix'):
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax, cbar=False)
    ax.set_xlabel('Predicted labels')
    ax.set_ylabel('True labels')
    ax.set_title(title)
    st.pyplot(fig)

def calculate_metrics(cm):
    TN, FP, FN, TP = cm.ravel()
    accuracy = (TP + TN) / (TP + TN + FP + FN)
    precision = TP / (TP + FP) if (TP + FP) != 0 else 0
    recall = TP / (TP + FN) if (TP + FN) != 0 else 0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) != 0 else 0
    return accuracy, precision, recall, f1

def app():
    st.title('Machine Learning Model Evaluation')

    ml = MachineLearning()

    results = []

    # Logistic Regression
    st.header('Logistic Regression')
    cm, acc = ml.LR()
    acc, precision, recall, f1 = calculate_metrics(cm)
    st.write(f"Accuracy: {acc:.2f}")
    st.write(f"Precision: {precision:.2f}")
    st.write(f"Recall: {recall:.2f}")
    st.write(f"F1 Score: {f1:.2f}")
    display_confusion_matrix(cm, title='Logistic Regression Confusion Matrix')
    results.append(('Logistic Regression', acc, precision, recall, f1))

    # K-Nearest Neighbors
    st.header('K-Nearest Neighbors')
    cm, acc = ml.KNN()
    acc, precision, recall, f1 = calculate_metrics(cm)
    st.write(f"Accuracy: {acc:.2f}")
    st.write(f"Precision: {precision:.2f}")
    st.write(f"Recall: {recall:.2f}")
    st.write(f"F1 Score: {f1:.2f}")
    display_confusion_matrix(cm, title='K-Nearest Neighbors Confusion Matrix')
    results.append(('K-Nearest Neighbors', acc, precision, recall, f1))

    # Naive Bayes
    st.header('Naive Bayes')
    cm, acc = ml.NB()
    acc, precision, recall, f1 = calculate_metrics(cm)
    st.write(f"Accuracy: {acc:.2f}")
    st.write(f"Precision: {precision:.2f}")
    st.write(f"Recall: {recall:.2f}")
    st.write(f"F1 Score: {f1:.2f}")
    display_confusion_matrix(cm, title='Naive Bayes Confusion Matrix')
    results.append(('Naive Bayes', acc, precision, recall, f1))

    # Decision Tree
    st.header('Decision Tree')
    cm, acc = ml.DT()
    acc, precision, recall, f1 = calculate_metrics(cm)
    st.write(f"Accuracy: {acc:.2f}")
    st.write(f"Precision: {precision:.2f}")
    st.write(f"Recall: {recall:.2f}")
    st.write(f"F1 Score: {f1:.2f}")
    display_confusion_matrix(cm, title='Decision Tree Confusion Matrix')
    results.append(('Decision Tree', acc, precision, recall, f1))

    # Random Forest
    st.header('Random Forest')
    cm, acc = ml.RF()
    acc, precision, recall, f1 = calculate_metrics(cm)
    st.write(f"Accuracy: {acc:.2f}")
    st.write(f"Precision: {precision:.2f}")
    st.write(f"Recall: {recall:.2f}")
    st.write(f"F1 Score: {f1:.2f}")
    display_confusion_matrix(cm, title='Random Forest Confusion Matrix')
    results.append(('Random Forest', acc, precision, recall, f1))

    # Display summary histogram
    df_results = pd.DataFrame(results, columns=['Model', 'Accuracy', 'Precision', 'Recall', 'F1 Score'])
    df_results.set_index('Model', inplace=True)
    
    st.header('Model Performance Comparison')
    fig, ax = plt.subplots(figsize=(10, 6))
    df_results.plot(kind='bar', ax=ax)
    ax.set_ylabel('Score')
    ax.set_title('Comparison of Model Performance Metrics')
    st.pyplot(fig)

if __name__ == "__main__":
    app()

