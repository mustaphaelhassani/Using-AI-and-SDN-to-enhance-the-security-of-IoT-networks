import streamlit as st
import os
import subprocess
import signal
import sys
import time
import pandas as pd
import altair as alt

def save_pid(filename, pid):
    with open(filename, 'w') as f:
        f.write(str(pid))

def get_pid(filename):
    try:
        with open(filename, 'r') as f:
            return int(f.read().strip())
    except FileNotFoundError:
        return None

def remove_pid(filename):
    if os.path.exists(filename):
        os.remove(filename)

def plot_data(file_path):
    try:
        data = pd.read_csv(file_path)
        if data.empty:
            st.write("No data to display yet.")
            return

        st.write("## Event Count")
        st.write(data.shape[0])

        # Convert timestamp to datetime format
        data['timestamp'] = pd.to_datetime(data['timestamp'], unit='s')

        # Events over Time
        st.write("## Events over Time")
        event_count = data.set_index('timestamp').resample('30S').size().reset_index(name='count')
        line_chart = alt.Chart(event_count).mark_bar().encode(
            x='timestamp:T',
            y='count:Q'
        ).properties(width=800, height=400)
        st.altair_chart(line_chart, use_container_width=True)

        # Event Sources
        st.write("## Event Sources")
        event_sources = data['source'].value_counts().reset_index()
        event_sources.columns = ['source', 'count']
        pie_chart = alt.Chart(event_sources).mark_arc().encode(
            theta=alt.Theta(field="count", type="quantitative"),
            color=alt.Color(field="source", type="nominal")
        ).properties(width=400, height=400)
        st.altair_chart(pie_chart, use_container_width=True)

    except Exception as e:
        st.write(f"Error in plotting data: {e}")

def app():
    st.title("Network Traffic Data Collection and Visualization")
    
    benign_pid_file = '/tmp/benign_traffic_pid.txt'
    ddos_pid_file = '/tmp/ddos_traffic_pid.txt'
    script_directory = "/home/ryu/PFE_IDS_IOT_SDN/controller"
    benign_data_file = os.path.join(script_directory, 'FlowStatsfile.csv')
    ddos_data_file = os.path.join(script_directory, 'FlowStatsfile.csv')

    # Start collecting benign traffic data
    if st.button("Start Collecting Benign Traffic"):
        st.write("Starting benign traffic collection...")
        script_path = "collect_benign_trafic1.py"
        try:
            process = subprocess.Popen([sys.executable, "-m", "ryu.cmd.manager", script_path], cwd=script_directory, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            save_pid(benign_pid_file, process.pid)
            st.write(f"Benign traffic collection started successfully with PID {process.pid}!")
        except Exception as e:
            st.write(f"Error running script: {e}")

    # Stop collecting benign traffic data
    if st.button("Stop Collecting Benign Traffic"):
        process_id_benign = get_pid(benign_pid_file)
        if process_id_benign:
            st.write(f"Stopping benign traffic collection with PID {process_id_benign}...")
            try:
                os.kill(process_id_benign, signal.SIGTERM)
                remove_pid(benign_pid_file)
                st.write("Benign traffic collection stopped successfully!")
            except Exception as e:
                st.write(f"Error stopping script: {e}")
        else:
            st.write("No benign traffic collection process to stop.")

    # Start collecting DDoS attack data
    if st.button("Start Collecting DDoS Attack Data"):
        st.write("Starting DDoS attack data collection...")
        script_path = "collect_ddos_trafic.py"
        try:
            process = subprocess.Popen([sys.executable, "-m", "ryu.cmd.manager", script_path], cwd=script_directory, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            save_pid(ddos_pid_file, process.pid)
            st.write(f"DDoS attack data collection started successfully with PID {process.pid}!")
        except Exception as e:
            st.write(f"Error running script: {e}")

    # Stop collecting DDoS attack data
    if st.button("Stop Collecting DDoS Attack Data"):
        process_id_ddos = get_pid(ddos_pid_file)
        if process_id_ddos:
            st.write(f"Stopping DDoS attack data collection with PID {process_id_ddos}...")
            try:
                os.kill(process_id_ddos, signal.SIGTERM)
                remove_pid(ddos_pid_file)
                st.write("DDoS attack data collection stopped successfully!")
            except Exception as e:
                st.write(f"Error stopping script: {e}")
        else:
            st.write("No DDoS attack data collection process to stop.")

    st.write("## Benign Traffic Data Visualization")
    plot_data(benign_data_file)

    st.write("## DDoS Attack Data Visualization")
    plot_data(ddos_data_file)

    time.sleep(1)  # Delay to avoid too frequent updates
    st.experimental_rerun()  # Automatically refresh the app to show real-time data

if __name__ == "__main__":
    app()

