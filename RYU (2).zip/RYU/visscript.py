import pandas as pd
import matplotlib.pyplot as plt

# Charger les données à partir du fichier CSV
df = pd.read_csv('FlowStatsfile.csv')

# Afficher les premières lignes du DataFrame et les colonnes disponibles
print(df.head())
print(df.columns)

# Convertir le timestamp en datetime pour une meilleure gestion du temps
df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')

# Demander à l'utilisateur de saisir la date et l'heure de début et de fin pour le filtrage
start_date = input("Entrez la date et l'heure de début (format : YYYY-MM-DD HH:MM:SS) : ")
end_date = input("Entrez la date et l'heure de fin (format : YYYY-MM-DD HH:MM:SS) : ")

# Convertir les entrées utilisateur en datetime
start_date = pd.to_datetime(start_date)
end_date = pd.to_datetime(end_date)

# Filtrer les données en fonction de la plage de dates spécifiée
filtered_df = df[(df['timestamp'] >= start_date) & (df['timestamp'] <= end_date)]

# Ajouter une colonne pour les minutes
filtered_df['minute'] = filtered_df['timestamp'].dt.floor('T')

# Agréger les données par minute et label (0 pour normal, 1 pour malveillant)
aggregated_data = filtered_df.groupby(['minute', 'label']).size().unstack(fill_value=0)

# Renommer les colonnes pour plus de clarté
aggregated_data.columns = ['Normal Traffic', 'Malicious Traffic']

# Vérifier la forme des données agrégées
print(aggregated_data.head())

# Créer une courbe empilée
ax = aggregated_data.plot(kind='bar', stacked=True, figsize=(12, 6), color=['green', 'red'])

# Ajouter des étiquettes et un titre
plt.xlabel('Time')
plt.ylabel('Traffic Count')
plt.title('Normal vs Malicious Traffic Over Time')
plt.legend(loc='upper left')

# Afficher la courbe
plt.show()

